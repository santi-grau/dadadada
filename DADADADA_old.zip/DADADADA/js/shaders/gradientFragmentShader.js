precision highp float;
uniform float r1, g1, b1, r2, g2, b2, r3, g3, b3, logoTop, logoBot, logoHeightTop, logoHeightBot;
uniform sampler2D tOne;
varying vec2 vUv;
void main( void ) {
	vec2 position =  vUv;
	vec4 Ca = texture2D(tOne, vUv);
	float red,green,blue,mult;
	if(position.y > logoBot && position.y < logoTop){
		red = r1/255.0 * Ca.a;
		green = g1/255.0 * Ca.a;
		blue = b1/255.0 * Ca.a;
	}else{
		//if(position.y <= logoBot) mult = (position.y - logoHeightBot) / (logoBot - logoHeightBot);
		if(position.y >= logoTop){
			mult = 1. - (position.y - logoTop) / (logoHeightTop - logoTop);
			red = (r1 * mult/255.0 + r2 * (1.0 - mult) /255.0) * Ca.a;
			green = (g1 * mult/255.0 + g2 * (1.0 - mult) /255.0) * Ca.a;
			blue = (b1 * mult/255.0 + b2 * (1.0 - mult) /255.0) * Ca.a;
		}
		if(position.y <= logoBot){
			mult = (position.y - logoHeightBot) / (logoBot - logoHeightBot);
			red = (r1 * mult/255.0 + r3 * (1.0 - mult) /255.0) * Ca.a;
			green = (g1 * mult/255.0 + g3 * (1.0 - mult) /255.0) * Ca.a;
			blue = (b1 * mult/255.0 + b3 * (1.0 - mult) /255.0) * Ca.a;
		}
	}
	gl_FragColor = vec4( red, green, blue, Ca.a );
}