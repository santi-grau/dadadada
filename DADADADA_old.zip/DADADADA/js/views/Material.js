// ┌────────────────────────────────────────────────────────────────────┐
// | Gradient.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone',
		'text!shaders/gradientFragmentShader.js',
		'text!shaders/gradientVertexShader.js',
		'color'
	],
	function(Backbone, GradientFragmentShader, GradientVertexShader, ColorConvert){
		var Gradient = Backbone.View.extend({
			initialize: function(data){	
				_.extend(this,data);
				window.App.Models.Logo.on('change:color change:color2 change:color3', this.setColor, this);
				var col1 = ColorConvert(window.App.Models.Logo.get('color'));
				var col2 = ColorConvert(window.App.Models.Logo.get('color2'));
				var col3 = ColorConvert(window.App.Models.Logo.get('color3'));
				//console.log(ColorConvert(window.App.Models.Logo.get('color')).red());
				this.texture = this.makeTexture(window.App.Models.Logo.get('logoImage'));
				this.uniforms = {
					r1: { type: "f", value: col1.r() * 255 },
					g1: { type: "f", value: col1.g() * 255 },
					b1: { type: "f", value: col1.b() * 255 },
					r2: { type: "f", value: col2.r() * 255 },
					g2: { type: "f", value: col2.g() * 255 },
					b2: { type: "f", value: col2.b() * 255 },
					r3: { type: "f", value: col3.r() * 255 },
					g3: { type: "f", value: col3.g() * 255 },
					b3: { type: "f", value: col3.b() * 255 },
					logoTop: { type: "f", value: 1},
					logoBot: { type: "f", value: 0 },
					logoHeightTop: { type: "f", value: 1 },
					logoHeightBot: { type: "f", value: 0 },
					resolution: { type: "v2", value: new THREE.Vector2() },
					tOne: { type: "t", value: this.texture }
				};
				this.shader = new THREE.ShaderMaterial( { 
					uniforms: this.uniforms,
					vertexShader: GradientVertexShader,
					fragmentShader: GradientFragmentShader
				});
			},
			setColor: function(model){
				var self = this;
				for(var propertyName in model.changedAttributes()) {
					var color = ColorConvert(model.get(propertyName));
					if(propertyName == 'color'){
						this.uniforms.r1.value = color.r() * 255;
						this.uniforms.g1.value = color.g() * 255;
						this.uniforms.b1.value = color.b() * 255;
					}
					if(propertyName == 'color2'){
						this.uniforms.r2.value = color.r() * 255;
						this.uniforms.g2.value = color.g() * 255;
						this.uniforms.b2.value = color.b() * 255;
					}
					if(propertyName == 'color3'){
						this.uniforms.r3.value = color.r() * 255;
						this.uniforms.g3.value = color.g() * 255;
						this.uniforms.b3.value = color.b() * 255;
					}
				}
			},
			makeTexture: function(data, mapping, callback){
				var image = new Image(), texture = new THREE.Texture( image, mapping );
				image.onload = function () { texture.needsUpdate = true; if ( callback ) callback( this ); };
				image.crossOrigin = this.crossOrigin;
				image.src = data;
				return texture;
			},
			refresh: function(model){
				var maxTop = -_.last(_.sortBy(window.App.Models.TopWave.get('wave'), function(particle){ return Math.abs(particle.y); })).y;
				var maxBot = _.last(_.sortBy(window.App.Models.BotWave.get('wave'), function(particle){ return Math.abs(particle.y); })).y;
				var totalHeight = window.App.Models.Logo.get('meshHeight') + Math.abs(maxBot) + Math.abs(maxTop);
				var logoBot = maxBot / totalHeight;
				var logoTop = (totalHeight + maxTop) / totalHeight;
				this.uniforms.logoBot.value = logoBot;
				this.uniforms.logoTop.value = logoTop;
			}
		});
		return Gradient;
	}
);