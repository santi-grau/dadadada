// ┌────────────────────────────────────────────────────────────────────┐
// | Ui.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone',
		'color'
	],
	function(Backbone, ColorConvert){
		var Ui = Backbone.View.extend({
			el: '#ui',
			events: {
				'click .src' : 'setAudioSource',
				'click .type' : 'setLogoType',
				'click #switch' : 'toggleLogoType',
				'click .linkCont' : 'toggleLink',
				'click .colSelector' : 'openColorSelector',
				'mouseleave .colSelector' : 'closeColorDrag',
				'mousedown .rainbow' : 'startColorDrag',
				'mousemove .rainbow' : 'colorDrag',
				'mouseup .rainbow' : 'endColorDrag',
				'mousedown .black' : 'setBlack',
				'mousedown .white' : 'setWhite',
				'mousemove .black, .white' : 'setColorSelector',
				'keyup #colorCode input' : 'colortype'
			},
			initialize: function(){	
				window.App.Models.Analyser.on('change:source', this.setSoure, this);
				window.App.Models.Logo.on('change:type', this.setType, this);
				window.App.Models.Logo.on('change:background', this.setBackground, this);
				window.App.Models.Logo.on('change:color change:color2 change:color3', this.setForeground, this);
				var logoModel = window.App.Models.Logo;
				$('body').css('background-color', logoModel.get('background'));
				this.$('.changeable').css('background', logoModel.get('background'));
				this.$('.colSelector[data-model=color]').find('.bgColor').css('background', logoModel.get('color'));
				this.$('.colSelector[data-model=color2]').find('.bgColor').css('background', logoModel.get('color2'));
				this.$('.colSelector[data-model=color3]').find('.bgColor').css('background', logoModel.get('color3'));
			},
			setAudioSource: function(e){
				e.preventDefault();
				window.App.Models.Analyser.set('source', $(e.currentTarget).data('src'));
			},
			setSoure: function(model, source){
				this.$('.src.active').removeClass('active');
				this.$('.src[data-src='+source+']').addClass('active');
				if(source == 'video'){
					this.$('#bgSelector').removeClass('vis');
					$('.changeable').css('background', '#FFFFFF');
				}else{
					this.$('#bgSelector').addClass('vis');
					$('.changeable').css('background', window.App.Models.Logo.get('background'));
				}
			},
			toggleLogoType: function(){
				var logoModel = window.App.Models.Logo;
				if(logoModel.get('type') == 'vector') logoModel.set('type', 'raster');
				else if(logoModel.get('type') == 'raster') logoModel.set('type', 'vector');
				this.setType(logoModel);
			},
			setLogoType: function(e){
				e.preventDefault();
				window.App.Models.Logo.set('type', $(e.currentTarget).data('type'));
			},
			setType: function(model){
				var type = (model.get('type'));
				this.$('#switch .selector').removeClass('vector raster')
				this.$('#switch .selector').addClass(type);
			},
			toggleLink: function(e){
				e.preventDefault();
				$(e.currentTarget).toggleClass('unlink')
			},
			setBackground: function(model, attr){
				$('body').addClass('changing').css('background-color', attr);
				$('.changeable').css('background', attr);
			},
			setForeground: function(model, attr){
				var key = _.keys(model.changedAttributes())[0];
				this.$('.colSelector[data-model='+key+']').find('.bgColor').css('background', attr);
			},
			openColorSelector: function(e){
				e.preventDefault();
				var target = e.currentTarget;
				$(target).addClass('active');
				this.getColor(e);
			},
			setColorSelector: function(e){
				e.preventDefault();
				var className = e.target.className;
				if(className == 'white') this.moveColorCode(e, '#FFFFFF');
				else if(className == 'black')this.moveColorCode(e, '#000000');
			},
			startColorDrag: function(e){
				e.preventDefault();
				if(e.target.className !== 'rainbow') return;
				this.dragging = true;
				var color = this.getColor(e);
				this.setColor(color, $(e.currentTarget).parents('.colSelector').data('model'));
			},
			moveColorCode: function(e, color){
				e.preventDefault();
				this.$('#colorCode').css({
					'transform' : 'translate(' + (e.pageX) + 'px, ' + (e.pageY) + 'px)',
					'-webkit-transform' : 'translate(' + (e.pageX) + 'px, ' + (e.pageY) + 'px)',
					'-moz-transform' : 'translate(' + (e.pageX) + 'px, ' + (e.pageY) + 'px)',
					'-ms-transform' : 'translate(' + (e.pageX) + 'px, ' + (e.pageY) + 'px)',
					'-o-transform' : 'translate(' + (e.pageX) + 'px, ' + (e.pageY) + 'px)'
				})
				this.$('#colorCode input').val(color.toUpperCase())
			},
			getColor: function(e){
				e.preventDefault();
				var target = $(e.currentTarget);
				var model = target.parents('.colSelector').data('model')
				var circCenterX = target.width() / 2;
				var circCenterY = target.height() / 2;
				var mouseX = e.offsetX - circCenterX;
				var mouseY = e.offsetY - circCenterY;
				var angle = Math.atan2(mouseY, mouseX) * 180 / Math.PI + 150;
				var lineDistance = this.lineDistance({x: circCenterX, y: circCenterY}, {x: mouseX, y: mouseY});
				if(e.target.className !== 'rainbow') return;
				if(!this.$('#colorCode').hasClass('active'))
					this.$('#colorCode input').val(this.$('#colorCode input').val().toUpperCase())
					this.$('#colorCode input').focus();
					this.$('#colorCode').addClass('active');
					this.$('#colorCode input').data('model', model);
				var colorHex = ColorConvert('hsv('+ Math.abs(angle > 0 ? angle : 360+angle) +', 100%, 100%)').hex();
				this.moveColorCode(e, colorHex);
				if(lineDistance > 10) return ColorConvert('hsv('+ Math.abs(angle > 0 ? angle : 360+angle) +', 100%, 100%)').css();
			},
			lineDistance: function( point1, point2 ){
				var xs = Math.pow(point2.x - point1.x, 2);
				var ys = Math.pow(point2.y - point1.y, 2);
				return Math.sqrt( xs + ys );
			},
			colorDrag: function(e){
				e.preventDefault();
				if(e.target.className !== 'rainbow') return;
				var color = this.getColor(e);
				if(this.dragging) this.setColor(color, $(e.currentTarget).parents('.colSelector').data('model'))
			},
			endColorDrag: function(e){
				e.preventDefault();
				this.dragging = false;
			},
			closeColorDrag: function(e){
				e.preventDefault();
				var target = e.currentTarget;
				$(target).removeClass('active');
				this.$('#colorCode input').blur();
				this.$('#colorCode').removeClass('active');
			},
			setBlack: function(e){
				e.preventDefault();
				if(e.target.className !== 'black') return;
				var target = $(e.currentTarget);
				var model = target.parents('.colSelector').data('model');
				this.setColor('rgb(0,0,0)', model);
			},
			setWhite: function(e){
				e.preventDefault();
				if(e.target.className !== 'white') return;
				var target = $(e.currentTarget);
				var model = target.parents('.colSelector').data('model');
				this.setColor('rgb(255,255,255)', model);
			},
			colortype: function(e){
				var target = $(e.currentTarget);
				var model = target.data('model');
				if(/(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(target.val())) this.setColor(ColorConvert(target.val()).css(), model);
			},
			setColor: function(color, model){
				console.log(model)
				if(!color) return;
				if(model == 'background'){
					window.App.Models.Logo.set(model, color);
				}
				if(model == 'color'){
					window.App.Models.Logo.set(model, color);
					if(!this.$('#topCont').hasClass('unlink')){
						window.App.Models.Logo.set('color2', color);
					}
					if(!this.$('#botCont').hasClass('unlink')){
						window.App.Models.Logo.set('color3', color);
					}
				}
				if(model == 'color2'){
					window.App.Models.Logo.set(model, color);
					if(!this.$('#topCont').hasClass('unlink')){
						window.App.Models.Logo.set('color', color);
						if(!this.$('#botCont').hasClass('unlink')){
							window.App.Models.Logo.set('color3', color);
						}
					}
				}
				if(model == 'color3'){
					window.App.Models.Logo.set(model, color);
					if(!this.$('#botCont').hasClass('unlink')){
						window.App.Models.Logo.set('color', color);
						if(!this.$('#topCont').hasClass('unlink')){
							window.App.Models.Logo.set('color2', color);
						}
					}
				}
			}
		});
		return Ui;
	}
);