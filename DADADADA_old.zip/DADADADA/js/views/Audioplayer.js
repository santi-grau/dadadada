// ┌────────────────────────────────────────────────────────────────────┐
// | Audioplayer.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone',
		'two'
	],
	function(Backbone, Two){
		var Audioplayer = Backbone.View.extend({
			events: {
				'click #playBut' : 'togglePlay'
				// 'mousedown #wave' : 'startScrub',
				// 'mousemove #wave' : 'scrubDrag',
				// 'mouseup #wave' : 'stopScrub'
			},
			el: '#audioPlayer',
			initialize: function(){	
				window.App.Models.Analyser.on('change:buffer', this.setSource, this);
				window.App.Models.Analyser.on('change:source', this.showHide, this);
				window.App.Models.Analyser.on('change:currentTime', this.showPlay, this);
				window.App.Models.Analyser.on('change:playing', this.togglePlayBut, this);
				window.App.Models.Logo.on('change:background', this.setBackground, this);
				this.$('.changeable').css('background', window.App.Models.Logo.get('background'));
			},
			// startScrub: function(e){
			// 	window.App.Models.Analyser.set('scrubbing' , true);
			// },
			// scrubDrag: function(e){
			// 	if(window.App.Models.Analyser.get('scrubbing')){
			// 		var position = (e.offsetX / this.$('#wave').width()) * window.App.Models.Analyser.get('buffer').duration;
			// 		window.App.Models.Analyser.set('currentTime', position);
			// 	}
			// },
			// stopScrub: function(e){
			// 	window.App.Models.Analyser.set('scrubbing' , false);
			// },
			showHide: function(model, attr){
				if(!model.get('buffer')) return;
				if(attr == 'audio' || attr == 'video') this.$el.addClass('active');
				else return this.$el.removeClass('active')
			},
			setSource: function(model, attr){
				this.$('#wave').find('svg').remove();
				var buffer = model.get('buffer');
				var definition = 2
				var waveWidth = this.$('#wave').width();
				var sampleStep = Math.round( buffer.length / waveWidth / definition);
				var vertices = [];
				var two = new Two({width: this.$('#wave').width(), height: this.$('#wave').height(), autostart: true, type: Two.Types['svg']}).appendTo(this.$('#wave')[0]);
				for(i = 0; i < waveWidth; i+=definition){
					vertices.push( new Two.Anchor( i, - Math.abs( buffer.getChannelData(0)[i*sampleStep] * this.$('#wave').height()/2 + 3) + this.$('#wave').height()/2 ) );
				}
				for(i = vertices.length-1; i >= 0 ; i--){
					vertices.push( new Two.Anchor( vertices[i].x, this.$('#wave').height()-vertices[i].y ) );
				}
				var poly = new Two.Polygon(vertices, true);
				poly.noStroke();
				
				poly.fill = 'rgba(0, 0, 0, 0.1)';
				two.add(poly);

				var twotwo = new Two({width: this.$('#wave').width(), height: this.$('#wave').height(), autostart: true, type: Two.Types['svg']}).appendTo(this.$('#darkWave')[0]);
				var poly = new Two.Polygon(vertices, true);
				poly.noStroke();
				if(model.get('source') == 'audio') poly.fill = 'rgba(0, 0, 0, 0.1)';
				if(model.get('source') == 'video') poly.fill = 'rgba(0, 0, 0, 0.4)';
				twotwo.add(poly);
			},
			togglePlayBut: function(model, attr){
				if(!attr) this.$('#playBut').removeClass('active');
				if(attr) if(!attr) this.$('#playBut').addClass('active');
				if(model.get('source') == 'audio' || model.get('source') == 'video') this.$el.addClass('active');
				else return this.$el.removeClass('active')
			},
			togglePlay: function(e){
				$(e.currentTarget).toggleClass('active')
				if(window.App.Models.Analyser.get('source') == 'video') return this.toggleVideoPlay();
				window.App.Models.Analyser.toggleBufferPlay();
			},
			toggleVideoPlay: function(){
				if(window.App.Models.Analyser.get('playing')){
					window.App.video.pause();
					window.App.Models.Analyser.set('playing', false);
				}else if(!window.App.Models.Analyser.get('playing')){
					window.App.video.play();
					window.App.Models.Analyser.set('playing', true);
				}
			},
			setBackground: function(model, attr){
				this.$('.changeable').css('background', attr);
			},
			showPlay: function(model, attr){
				this.$('#darkWave').css('width', (attr/model.get('buffer').duration)*100 + '%')
			},
			updateTime: function(e){
				this.$('#darkWave').css('width', (e.target.currentTime/e.target.duration)*100 + '%')
			}
		});
		return Audioplayer;
	}
);