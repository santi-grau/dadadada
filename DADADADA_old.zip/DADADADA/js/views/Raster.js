// ┌────────────────────────────────────────────────────────────────────┐
// | Raster.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone',
		'three',
		'views/Mesh'
	],
	function(Backbone, Three, Mesh){
		var Raster = Backbone.View.extend({
			el: '#canvas',
			model: new Mesh(),
			initialize: function(){	
				this.createScene();
			},
			createScene: function(){
				this.scene = new THREE.Scene();
				this.camera = new THREE.OrthographicCamera( this.$el.width() / - 2, this.$el.width() / 2, this.$el.height() / 2, this.$el.height() / - 2, 0, 1000 );
				this.camera.position.z = 50;
				this.camera.updateProjectionMatrix();
				this.renderer = new THREE.WebGLRenderer( { antialias: true, preserveDrawingBuffer: true, autoClearStencil: false, alpha: true, devicePixelRatio: Math.min(window.devicePixelRatio) || 1 } );
				this.renderer.setSize(this.$el.width(), this.$el.height());
				this.$el.append(this.renderer.domElement);
				this.mesh = new Mesh();
				this.scene.add(this.mesh.makeMesh());
			},
			render: function(){
				this.mesh.animate();
				this.renderer.render(this.scene, this.camera);
			}
		});
		return Raster;
	}
);