// ┌────────────────────────────────────────────────────────────────────┐
// | Mesh.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone',
		'views/Material',
		'models/Particle'
	],
	function(Backbone, Material, Particle){
		var Mesh = Backbone.View.extend({
			initialize: function(){	
			},
			makeMesh: function(){
				this.makeParticles();
				this.windForce = new THREE.Vector3(0,0,0);
				this.tmpForce = new THREE.Vector3();
				var plane = this.plane(window.App.Models.Logo.get('xSegs') * window.App.Models.Logo.get('restDistanceX'), window.App.Models.Logo.get('ySegs') * window.App.Models.Logo.get('restDistanceY'));
				this.geometry = new THREE.ParametricGeometry( plane, window.App.Models.Logo.get('xSegs'), window.App.Models.Logo.get('ySegs'));
				
				var material = new THREE.MeshBasicMaterial({wireframe: true, wireframeLinewidth: 1, color : '#000000'})
				var mesh = new THREE.Mesh( this.geometry, material )

				this.material = new Material();
				var mesh = new THREE.Mesh( this.geometry, this.material.shader )
				
				mesh.castShadow = false;
				mesh.receiveShadow = false;
				return mesh;
			},
			animate: function(model){
				if(!window.App.Models.Analyser.get('playing') && (window.App.Models.Analyser.get('source') == 'video' || window.App.Models.Analyser.get('source') == 'audio')) return;
				
				var botWave = window.App.Models.BotWave.get('wave');
				var topWave = window.App.Models.TopWave.get('wave');
				var particles = window.App.Models.Logo.get('particles');
				var lastIndex = particles.length - window.App.Models.Logo.get('xSegs') - 1;
				_.each(botWave, _.bind(function(e,i){
					particles[i].position.y = particles[i].original.y - e.y;
				},this));
				_.each(topWave, _.bind(function(e,i){
					particles[(lastIndex + i)].position.y = particles[(lastIndex + i)].original.y  + e.y;
				},this));
				_.each(particles, _.bind(function(e,i){
					particles[i].position.x = particles[i].original.x;
				},this))
				
				window.App.Models.Logo.set('particles', particles)
				var p = _.clone(window.App.Models.Logo.get('particles'));
				for ( var i = 0, il = p.length; i < il; i ++ ) {
					this.geometry.vertices[ i ].copy( p[ i ].position );
				}
				if(this.material && this.material.refresh) this.material.refresh();
				this.simulate();
				this.geometry.normalsNeedUpdate = true;
				this.geometry.verticesNeedUpdate = true;
			},
			simulate: function(){
				var time = Date.now();
				if (!this.lastTime) {
					this.lastTime = time;
					return;
				}
				var i, il, particles, particle, pt, constrains, constrain;
				var face, faces = this.geometry.faces, normal;
				var particles = window.App.Models.Logo.get('particles');
				for (i=0,il=faces.length;i<il;i++) {
					face = faces[i];
					normal = face.normal;
					this.tmpForce.copy(normal).normalize().multiplyScalar(normal.dot(this.windForce));
					particles[face.a].addForce(this.tmpForce);
					particles[face.b].addForce(this.tmpForce);
					particles[face.c].addForce(this.tmpForce);
				}
				for (i=0, il = particles.length;i<il;i++) {
					particle = particles[i];
					particle.integrate(window.App.Models.Logo.get('TIMESTEP'));
				}
				constrains = this.constrains,
				il = constrains.length;
				for (i=0;i<il;i++) {
					constrain = constrains[i];
					this.satisifyConstrains(constrain[0], constrain[1], constrain[2], constrain[3], constrain[4]);
				}
			},
			satisifyConstrains: function(p1, p2, distance){
				var diff = new THREE.Vector3();
				diff.subVectors(p2.position, p1.position);
				var currentDist = diff.length();
				if (currentDist==0) return;
				var correction = diff.multiplyScalar(1 - distance/currentDist);
				var correctionHalf = correction.multiplyScalar(0.4);
				p1.position.add(correctionHalf);
				p2.position.sub(correctionHalf);

			},
			makeParticles: function(){
				var w = window.App.Models.Logo.get('xSegs');
				var h = window.App.Models.Logo.get('ySegs');
				var mass = window.App.Models.Logo.get('mass');
				var particles = _.clone(window.App.Models.Logo.get('particles'));
				var constrains = [];
				var u, v, r, c;
				for (v=0;v<=h;v++) {
					for (u=0;u<=w;u++) {
						var part = new Particle({logo: this.logo, model: this.model, x: u/w, y: v/h, z: 0, mass: mass, v: v, u: u });
						particles.push( part );
					}
				}
				for (v=0;v<h;v++) {
					for (u=0;u<w;u++) {
						constrains.push([particles[index(u, v)], particles[index(u, v+1)], window.App.Models.Logo.get('restDistanceY')]);
						constrains.push([particles[index(u, v)], particles[index(u+1, v)], window.App.Models.Logo.get('restDistanceX')]);
					}
				}
				for (u=w, v=0;v<h;v++) {
					constrains.push([particles[index(u, v)], particles[index(u, v+1)], window.App.Models.Logo.get('restDistanceY')]);
				}
				for (v=h, u=0;u<w;u++) { constrains.push([ particles[index(u, v)], particles[index(u+1, v)], window.App.Models.Logo.get('restDistanceX')]);
				}
				window.App.Models.Logo.set('particles', particles);
				this.constrains = constrains;
				function index(u, v) {
					return u + v * (w + 1);
				}
			},
			plane: function(width,height){
				return function(u, v) {
					var x = (u-0.5) * width;
					var y = (v-0.5) * height;
					var z = 0;
					return new THREE.Vector3(x, y, z);
				};
			}
		});
		return Mesh;
	}
);