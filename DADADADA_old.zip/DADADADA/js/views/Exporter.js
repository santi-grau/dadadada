// ┌────────────────────────────────────────────────────────────────────┐
// | Exporter.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone',
		'three',
		'text!shaders/gradientFragmentShader.js',
		'text!shaders/gradientVertexShader.js',
		'color'
	],
	function(Backbone, Three, GradientFragmentShader, GradientVertexShader, ColorConvert){
		var Exporter = Backbone.View.extend({
			el: '#exporter',
			initialize: function(){	
			},
			export: function(){
				this.texture = this.makeTexture(window.App.Models.Exporter.get('logoImage'));
			},
			render: function(){
				// make shader
				var col1 = ColorConvert(window.App.Models.Logo.get('color'));
				var col2 = ColorConvert(window.App.Models.Logo.get('color2'));
				var col3 = ColorConvert(window.App.Models.Logo.get('color3'));
				var scale = window.App.Models.Logo.get('restDistanceX') / window.App.Models.Exporter.get('restDistanceX');
				var maxTop = -_.last(_.sortBy(window.App.Models.TopWave.get('wave'), function(particle){ return Math.abs(particle.y); })).y;
				var maxBot = _.last(_.sortBy(window.App.Models.BotWave.get('wave'), function(particle){ return Math.abs(particle.y); })).y;
				var totalHeight = window.App.Models.Logo.get('meshHeight') + Math.abs(maxBot) + Math.abs(maxTop);
				var lB = maxBot / totalHeight;
				var lT = (totalHeight + maxTop) / totalHeight;
				var uniforms = {
					r1: { type: "f", value: col1.r() * 255 },
					g1: { type: "f", value: col1.g() * 255 },
					b1: { type: "f", value: col1.b() * 255 },
					r2: { type: "f", value: col2.r() * 255 },
					g2: { type: "f", value: col2.g() * 255 },
					b2: { type: "f", value: col2.b() * 255 },
					r3: { type: "f", value: col3.r() * 255 },
					g3: { type: "f", value: col3.g() * 255 },
					b3: { type: "f", value: col3.b() * 255 },
					logoTop: { type: "f", value: lB },
					logoBot: { type: "f", value: lT },
					logoHeightTop: { type: "f", value: 1 },
					logoHeightBot: { type: "f", value: 0 },
					resolution: { type: "v2", value: new THREE.Vector2() },
					tOne: { type: "t", value: this.texture }
				};
				var shader = new THREE.ShaderMaterial( { 
					uniforms: uniforms,
					vertexShader: GradientVertexShader,
					fragmentShader: GradientFragmentShader
				});
				// create scene
				var scene = new THREE.Scene();
				var camera = new THREE.OrthographicCamera( this.$el.width() / - 2, this.$el.width() / 2, this.$el.height() / 2, this.$el.height() / - 2, 0, 1000 );
				camera.position.z = 50;
				camera.updateProjectionMatrix();
				var renderer = new THREE.WebGLRenderer( { antialias: true, preserveDrawingBuffer: true, autoClearStencil: false, alpha: true, devicePixelRatio: Math.min(window.devicePixelRatio) || 1 } );
				renderer.setSize(this.$el.width(), this.$el.height());
				this.$el.append(renderer.domElement);

				// add mesh
				var plane = this.plane(window.App.Models.Exporter.get('xSegs') * window.App.Models.Exporter.get('restDistanceX'), window.App.Models.Exporter.get('ySegs') * window.App.Models.Exporter.get('restDistanceY'));
				geometry = new THREE.ParametricGeometry( plane, window.App.Models.Exporter.get('xSegs'), window.App.Models.Exporter.get('ySegs'));
				var mesh = new THREE.Mesh( geometry, shader )

			
				mesh.castShadow = false;
				mesh.receiveShadow = false;
				scene.add(mesh);

				// deform mesh
				var scale = window.App.Models.Exporter.get('scale');
				var vertices = window.App.Views.Raster.mesh.geometry.vertices;
				_.each(mesh.geometry.vertices, _.bind(function(e,i){
					e.y = vertices[i].y * scale;
				},this));

				// render
				renderer.render(scene, camera);

				// export
				var canvas = $(renderer.domElement);
				var context = canvas[0].getContext("experimental-webgl", {preserveDrawingBuffer: false});
				var image = canvas[0].toDataURL('image/png', 1);
				window.open(image, '_blank');
			},
			plane: function(width,height){
				return function(u, v) {
					var x = (u-0.5) * width;
					var y = (v-0.5) * height;
					var z = 0;
					return new THREE.Vector3(x, y, z);
				};
			},
			makeTexture: function(data, mapping, callback){
				var image = new Image(), texture = new THREE.Texture( image, mapping );
				image.onload = _.bind(function () {
					texture.needsUpdate = true;
					if ( callback ) callback( this );
					this.render();
				}, this);
				image.crossOrigin = this.crossOrigin;
				image.src = data;
				return texture;
			}
		});
		return Exporter;
	}
);