// ┌────────────────────────────────────────────────────────────────────┐
// | Vector.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone',
		'two',
		'text!svg/logo.svg'
	],
	function(Backbone, Two, Logo){
		var Vector = Backbone.View.extend({
			el: '#canvas',
			initialize: function(){	
				window.App.Models.Logo.on('change:color change:color2 change:color3', this.setColor, this);
				this.two = new Two({type: Two.Types['svg'], width: this.$el.width(), height: this.$el.height(), autostart: true}).appendTo(this.$el[0]);
				this.shape = this.two.interpret($(Logo)[0]);
				this.shape.center().translation.set(this.two.width / 2, this.two.height / 2);
				var dimensions = this.shape.getBoundingClientRect();
				var shapeAR = dimensions.height/dimensions.width;
				var canvasAR = this.$el.height()/this.$el.width();
				this.mid = this.$el.height()/2;
				this.shape.scale = this.$el.width()/dimensions.width;
				_.each(this.shape.children, _.bind(function(child, letter) {
					_.each(child.vertices, function(v) {
						v.ox = v.x;
						v.oy = v.y;
						v.r = v.y + dimensions.top;
					});
				},this));
				var col1 = window.App.Models.Logo.get('color');
				var col2 = window.App.Models.Logo.get('color2');
				var col3 = window.App.Models.Logo.get('color3');
				if(col1 !== col2 || col1 !== col3 || col2 !== col3) _.defer(_.bind(this.createGradient, this));
				else this.shape.fill = col1;
			},
			setColor: function(model){
				$('defs').html('')
				this.createGradient();
			},
			render: function(){
				var botWave = window.App.Models.BotWave.get('wave');
				var topWave = window.App.Models.TopWave.get('wave');
				var count = 0;
				var topValues = [];
				var botValues = [];
				_.each(botWave, _.bind(function(e,index){
					if(index % 4 === 0 && index !== 0) botValues.push(e.y);
				},this));
				_.each(topWave, _.bind(function(e,index){
					if(index % 4 === 0 && index !== 0) topValues.push(e.y);
				},this));
				_.each(this.shape.children, _.bind(function(child, index) {
					_.each(child.vertices, _.bind(function(v){
						var average = (botValues[count] + topValues[count]) / 2;
						if(v.r > this.mid) v.set(v.ox,v.oy + botValues[count]);
						if(v.r < this.mid) v.set(v.ox,v.oy - topValues[count]);
					}, this));
					count++;
				}, this));
			},
			createGradient: function(){
					var col1 = window.App.Models.Logo.get('color');
					var col2 = window.App.Models.Logo.get('color2');
					var col3 = window.App.Models.Logo.get('color3');
					var svg = $('#canvas svg')[0];
					var svgNS = svg.namespaceURI;
					var grad  = document.createElementNS(svgNS,'linearGradient');
					
					var id = 'grad';
					var stops = [
						{offset:'0%', 'stop-color': col2},
						{offset: '20%', 'stop-color': col1},
						{offset: '80%', 'stop-color': col1},
						{offset:'100%','stop-color': col3}
					]
					var attrs = { id : id, x1 : '0%', y1 : '0%', x2 : '0%', y2 : '100%' };
					for(var key in attrs) { grad.setAttribute(key, attrs[key]); }
						for (var i=0;i<stops.length;i++){
						var attrs = stops[i];
						var stop = document.createElementNS(svgNS,'stop');
						for (var attr in attrs){
							if (attrs.hasOwnProperty(attr)) stop.setAttribute(attr,attrs[attr]);
						}
						grad.appendChild(stop);
						var defs = svg.querySelector('defs') || svg.insertBefore( document.createElementNS(svgNS,'defs'), svg.firstChild);
						defs.appendChild(grad);
					}
					$('#canvas svg path').attr('fill','url(#grad)');
			},
			hexToRgb: function(hex) {
				var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
				return result ? { r: parseInt(result[1], 16), g: parseInt(result[2], 16), b: parseInt(result[3], 16) } : null;
			}
		});
		return Vector;
	}
);