// ┌────────────────────────────────────────────────────────────────────┐
// | SoundWaveView.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone'
	],
	function(Backbone){
		var SoundWaveView = Backbone.View.extend({
			el: '#soundWave',
			initialize: function(){	
				this.topWave = [];
				this.botWave = [];
				this.two = new Two({type: Two.Types['svg'], width: this.$el.width(), height: this.$el.height(), autostart: true}).appendTo(this.$el[0]);
				_.each(window.App.Models.TopWave.get('wave'), _.bind(function(point, index, points){
					var circ = this.two.makeCircle(point.x, point.y + this.two.height/3, 3);
					circ.fill = '#FF0000';
					circ.noStroke();
					this.topWave.push(circ);
				},this));
				_.each(window.App.Models.BotWave.get('wave'), _.bind(function(point, index, points){
					var circ = this.two.makeCircle(point.x, point.y + this.two.height - this.two.height/3, 3);
					circ.fill = '#FF0000';
					circ.noStroke();
					this.botWave.push(circ);
				},this));
			},
			step: function(){
				_.each(window.App.Models.TopWave.get('wave'), _.bind(function(point, index, points){
					this.topWave[index].translation.y = -point.y + this.two.height/3;
				},this));
				_.each(window.App.Models.BotWave.get('wave'), _.bind(function(point, index, points){
					this.botWave[index].translation.y = point.y + this.two.height - this.two.height/3;
				},this));
			}
		});
		return SoundWaveView;
	}
);