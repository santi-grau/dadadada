
Three.js on Bower
------

Current version: [r68](https://github.com/mrdoob/three.js/releases/tag/r68)

Visit official repo if you want to know more:

https://github.com/mrdoob/three.js#threejs

Original repo is too large for Bower, so I picked this out from offcial tags.

### Usage

```
bower install --save three.js
```

### License

MIT