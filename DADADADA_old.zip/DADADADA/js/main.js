// ┌────────────────────────────────────────────────────────────────────┐
// | main.js
// └────────────────────────────────────────────────────────────────────┘
'use strict';
require.config({
	shim: {
		underscore: {
			exports: '_'
		},
		backbone: {
			deps: [
				'underscore',
				'jquery'
			],
			exports: 'Backbone'
		},
		two: {
			deps: [
				'underscore',
				'backbone'
			],
			exports: 'Two'
		},
		three: {
			exports: 'THREE'
		},
		color: {
			exports: 'Color'
		},
		stats: {
			exports: 'Stats'
		}
	},
	paths: {
		jquery: 'libs/jquery/dist/jquery.min',
		underscore: 'libs/underscore/underscore-min',
		backbone: 'libs/backbone/backbone',
		text: 'libs/text/text',
		two: 'libs/two.js/build/two.min',
		three: 'libs/three.js/three.min',
		stats: 'libs/stats.js/build/stats.min',
		color: 'libs/color/one-color'
	}
});
require(['models/Logo', 'models/Analyser', 'models/Soundwave', 'views/Raster', 'views/Ui', 'views/SoundWaveView', 'views/Vector', 'views/Audioplayer','views/Exporter', 'models/Exporter', 'stats'],
	function(Logo, Analyser, Soundwave, Raster, Ui, SoundWaveView, Vector, Audioplayer, ExporterView, ExporterModel, Stats){
		var App = Backbone.View.extend({
			Models : {},
			Views : {},
			el: 'body',
			events: {
				'click #uiToggle' : 'uiToggle',
				'click #exportImage' : 'exportImage'
			},
			initialize: function(){
				this.Models.Logo = new Logo();
				this.Models.Logo.on('change:logoImage', this.LogoReady, this);
				this.Models.Logo.on('change:type', this.setType, this)
			},
			LogoReady: function(){
				this.Models.Analyser = new Analyser();
				this.Models.TopWave = new Soundwave({position: 'top'});
				this.Models.BotWave = new Soundwave({position: 'bot'});
				this.Views.Raster = new Raster();
				this.Views.Vector = new Vector();
				this.Views.Ui = new Ui();
				this.Views.Audioplayer = new Audioplayer();
				this.stats = new Stats();
				this.Models.Exporter = new ExporterModel();
				this.Views.Exporter = new ExporterView();
				this.Models.Exporter.on('change:logoImage', this.Views.Exporter.export, this.Views.Exporter);
				window.App.Models.Analyser.on('change:source', this.setSource, this);
				this.Views.Ui.$el.append( this.stats.domElement );
				window.addEventListener('drop', _.bind(this.Models.Analyser.drop, this.Models.Analyser) , false)
				$(window).bind('mousemove', _.bind(this.Models.TopWave.mouseMove, this.Models.TopWave));
				$(window).bind('mousemove', _.bind(this.Models.BotWave.mouseMove, this.Models.BotWave));
				$(window).bind('resize', _.bind(this.Models.Logo.resize, this.Models.Logo));
				$(window).bind('dragover', function(e) { e.preventDefault() });
				$(window).bind('dragenter', function(e) { e.preventDefault() });
				this.setType(this.Models.Logo);
				this.step();
			},
			resizeEnd: function(){
				this.Views.Raster.$el.html('');
				this.Views.Vector.$el.html('');
				this.Models.Logo = new Logo();
				this.Models.Logo.on('change:logoImage', this.LogoReady, this);
			},
			setSource: function(model, attr){
				if(attr == 'video'){
					$('video').show();
				}else{
					$('video').hide();
				}
			},
			setType: function(model){
				$('#canvas').attr('class', model.get('type'));
			},
			appendVideo: function(result){
				this.video = document.querySelector('video');
				var ms = new MediaSource();
				this.video.src = window.URL.createObjectURL(ms);
				this.video.ontimeupdate = _.bind(function(e) {
					window.App.Views.Audioplayer.updateTime(e);
				}, this);
				ms.addEventListener('sourceopen', _.bind(function(e) {
					var sourceBuffer = ms.addSourceBuffer('video/webm; codecs="vorbis,vp8"');
					sourceBuffer.appendBuffer(result.target.result);
					this.video.play()
				},this));
			},
			uiToggle: function(){
				this.Views.Ui.$el.toggleClass('active');
			},
			exportImage: function(){
				this.Models.Exporter.build();
			},
			step: function(){
				this.stats.update();
				this.Models.Analyser.step();
				this.Models.TopWave.step();
				this.Models.BotWave.step();
				if( this.Models.Logo.get('type') == 'raster' ) this.Views.Raster.render();
				if( this.Models.Logo.get('type') == 'vector' ) this.Views.Vector.render();
				if( this.Views.Soundwave ) this.Views.Soundwave.step();
				if(!window.App.Models.Logo.get('resizing')) requestAnimationFrame(_.bind(this.step,this));
			}
		});
		window.App = new App();
	}
);