// ┌────────────────────────────────────────────────────────────────────┐
// | UiModel.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone'
	],
	function(Backbone){
		var UiModel = Backbone.Model.extend({
			defaults: {
				waveWidth: null,
				buffer: null,
				leftChannel: [],
				rightChannel: [],
				mode: 'audio'
			},
			initialize: function(){
				
			},
			getWaveForm: function(buffer, width){
				var waveWidth = this.get('waveWidth');
				var sampleStep = Math.round(buffer.length / waveWidth);
				var leftChannel = [];
				var rightChannel = [];
				for(i = 0; i < waveWidth/5; i++){
					leftChannel.push(buffer.getChannelData(0)[i*sampleStep]);
					rightChannel.push(buffer.getChannelData(1)[i*sampleStep]);
				}
				this.set({
					buffer : buffer,
					leftChannel : leftChannel,
					rightChannel : rightChannel
				});
			}
		});
		return UiModel;
	}
);