// ┌────────────────────────────────────────────────────────────────────┐
// | SoundAnalyser.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone'
	],
	function(Backbone){
		var SoundAnalyser = Backbone.Model.extend({
			defaults: {
				average : 0,
				deep : 0,
				pitch : 0,
				freqByteData: [],
				micRequested: false,
				micGranted: false,
				audioSet: false,
				source: 'none',
				playing: false,
				elapsedTime: 0,
				pausedTime: 0,
				offsetTime: 0,
				currentTime: 0,
				bufferTime: 0,
				deep: 0,
				average: 0,
				pitch: 0,
				buffer: null,
				scrubbing: false
			},
			initialize: function(){
				var date = new Date();
				this.on('change:source', this.setSource, this);
				this.on('change:buffer', this.initBufferPlay, this);
				//this.on('change:currentTime', this.scrubbing, this);
				//this.on('change:scrubbing', this.scrubbingChange, this);
				window.AudioContext = window.AudioContext || window.webkitAudioContext ;
				this.context = new AudioContext();
				this.set('bufferTime', date.getTime());
				this.analyser = this.context.createAnalyser();
				this.analyser.fftSize = window.App.Models.Logo.get('SAdefinition');
				this.initByteBuffer();
			},
			initBufferPlay: function(model, attr){
				if(model.get('source') == 'video') return this.initVideoPlay();
				var buffer = this.get('buffer');
				var date = new Date();
				this.set('currentTime', 0);
				this.set('elapsedTime', 0);
				this.set('pausedTime', 0);
				this.set('offsetTime', date.getTime() - this.get('bufferTime'));
				this.mediaBufferSource = null;
				this.mediaBufferSource = this.context.createBufferSource();
				this.mediaBufferSource.connect(this.analyser);
				this.analyser.connect(this.context.destination);
				this.mediaBufferSource.loop = false;
				this.mediaBufferSource.buffer = buffer;
				this.mediaBufferSource.start(0,0);
				this.set('playing', true);
			},
			// scrubbing: function(){
			// 	if(this.get('scrubbing')){
			// 		// var buffer = this.get('buffer');
			// 		// this.mediaBufferSource = this.context.createBufferSource();
			// 		// this.mediaBufferSource.buffer = buffer;
			// 		// this.mediaBufferSource.connect(this.analyser);
			// 		// this.mediaBufferSource.start(this.get('currentTime'));

			// 		// _.defer(this.mediaBufferSource = null);
			// 		console.log(this.get('currentTime'))
			// 	}
			// },
			// scrubbingChange: function(model, attr){
			// 	if(!attr){
			// 		this.toggleBufferPlay(true);
			// 	}
			// },
			initVideoPlay: function(){
				this.set('playing', true);
			},
			toggleBufferPlay: function(stop){
				var buffer = this.get('buffer');
				var date = new Date();
				if(this.get('playing') || stop){
					this.set('currentTime',this.mediaBufferSource.context.currentTime - this.get('elapsedTime')/1000 - this.get('offsetTime')/1000);
					this.set('pausedTime', date.getTime());
					this.mediaBufferSource.stop();
					this.set('playing', false);
					this.mediaBufferSource = null;
				}else{
					this.set('elapsedTime', this.get('elapsedTime') +  (date.getTime() - this.get('pausedTime')));
					this.mediaBufferSource = this.context.createBufferSource();
					this.mediaBufferSource.buffer = buffer;
					this.mediaBufferSource.connect(this.analyser);
					this.mediaBufferSource.start(0,this.get('currentTime'));
					this.set('playing', true);
				}
			},
			setSource: function(model){
				var mode = model.get('source');
				var previousAttr = model.previousAttributes().source;
				if(mode == 'mic'){
					if(!this.get('micGranted') && !this.get('micRequested')){
						this.set('micRequested', true)
						navigator.webkitGetUserMedia({audio:true}, _.bind(function(stream){
							this.set('micGranted', true);
							this.stream = stream;
							this.mediaStreamSource = this.context.createMediaStreamSource(this.stream);
							this.mediaStreamSource.connect(this.analyser);
							if(this.get('playing')) this.toggleBufferPlay(true)
							if(this.mediaBufferSource) this.mediaBufferSource = null;
							this.analyser.disconnect(this.context.destination);
						},this), _.bind(this.noMicStream, this));
					}else{
						if(!this.stream) return;
						if(this.get('playing') && previousAttr == 'video') window.App.video.pause();
						if(this.get('playing') && previousAttr == 'audio') this.mediaBufferSource.stop();
						this.mediaStreamSource = this.context.createMediaStreamSource(this.stream);
						this.mediaStreamSource.connect(this.analyser);
						// if(this.get('playing')) this.toggleBufferPlay(true)
						if(this.mediaBufferSource) this.mediaBufferSource = null;
						this.analyser.disconnect(this.context.destination);
					}
				}
				if(mode == 'audio'){
					if(this.mediaStreamSource) this.mediaStreamSource.disconnect(this.analyser);
					this.analyser.disconnect(this.context.destination);
					this.analyser.connect(this.context.destination);
				}
				if(mode == 'video'){
					this.videoSource = this.context.createMediaElementSource($("video")[0]);
					this.videoSource.connect(this.context.destination);
					this.videoSource.connect(this.analyser);
				}
				if(mode == 'none'){
					if(this.get('playing') && previousAttr == 'video') window.App.video.pause();
					if(this.get('playing') && previousAttr == 'audio') this.mediaBufferSource.stop();
					if(this.mediaStreamSource) this.mediaStreamSource.disconnect(this.analyser);
					if(this.mediaBufferSource) this.mediaBufferSource.disconnect(this.analyser);
					if(this.mediaStreamSource) this.mediaStreamSource = null;
					if(this.mediaBufferSource) this.mediaBufferSource = null;
				}
			},
			initByteBuffer: function() {
				freqByteData = new Uint8Array(this.analyser.frequencyBinCount);
				this.set('freqByteData',freqByteData);
			},
			getAverage: function(arr){
				if(arr) return _.reduce(arr, function(memo, num){ return memo + num;}, 0) / arr.length;
				else return 0;
			},
			getValues: function(){
				//if((this.get('source') == 'audio' || this.get('source') == 'video') && !this.get('playing')) return;
				var freqByteData = this.get('freqByteData');
				this.analyser.getByteFrequencyData(freqByteData);
				this.set('freqByteData', freqByteData);
				if(freqByteData) this.set('deep', 1- (freqByteData[2]/255));
				if(freqByteData) this.set('average', freqByteData[8]/255);
				if(freqByteData) this.set('pitch', freqByteData[(freqByteData.length/2) - 2] / 255);
			},
			step: function(){
				this.getValues();
				if(this.mediaBufferSource) this.set('currentTime',this.mediaBufferSource.context.currentTime - this.get('elapsedTime')/1000 - this.get('offsetTime')/1000);
				//$('#analyserbar').css('height', this.get('average')*100 + '%')
			},
			lineDistance: function( point1, point2 ){
				var xs = Math.pow(point2.x - point1.x, 2);
				var ys = Math.pow(point2.y - point1.y, 2);
				return Math.sqrt( xs + ys );
			},
			noMicStream: function(){
				this.set('source', 'none');
				this.set('micRequested', false);
			},
			drop: function(e, handler){
				if (e.preventDefault) e.preventDefault();
				var file = e.dataTransfer.files[0];
				if(file.type.indexOf('audio') == -1 && file.type.indexOf('video') == -1) return alert('File not valid');
				if(file.type.indexOf('video') !== -1 && file.type.indexOf('webm') == -1) return alert('Only webm accepted!')
				var reader = new FileReader();
				if(file.type.indexOf('audio') !== -1){
					reader.onloadend = _.bind(function(result) {
						this.context.decodeAudioData(result.srcElement.result, _.bind(this.setBuffer, this), _.bind(this.badBuffer, this));
						if(this.get('playing') && this.get('source') == 'video') window.App.video.pause();
						if(this.get('playing') && this.get('source') == 'audio') this.mediaBufferSource.stop();
						this.set('source', 'audio');
					},this);
				}
				if(file.type.indexOf('video') !== -1){
					reader.onloadend = _.bind(function(result) {
						this.context.decodeAudioData(result.srcElement.result, _.bind(this.setBuffer, this), _.bind(this.badBuffer, this));
						window.App.appendVideo(result);
						if(this.get('playing') && this.get('source') == 'video') window.App.video.pause();
						if(this.get('playing') && this.get('source') == 'audio') this.mediaBufferSource.stop();
						this.set('source', 'video');
					},this);
				}
				reader.readAsArrayBuffer(file);
				return false;
			},
			setBuffer: function(buffer){
				this.set('buffer', buffer);
			},
			badBuffer: function(){
				alert('Bad noise bro!');
			}
		})
		return SoundAnalyser;
	}
);
