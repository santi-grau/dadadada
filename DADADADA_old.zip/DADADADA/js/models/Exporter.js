// ┌────────────────────────────────────────────────────────────────────┐
// | LogoModel.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone',
		'two',
		'text!svg/logo_compound.svg'
	],
	function(Backbone, Two, Logo){
		var Logomodel = Backbone.Model.extend({
			defaults: {
				SAdefinition: 128,
				canvasWidth: null, // total canvas width
				canvasHeight: null, // total canvas height
				meshWidth: null, // mesh width
				meshHeight: null, // mesh height
				logoImage : null,
				particles: [],
				constrains: [],
				restDistanceX : null,
				restDistanceY : null
			},
			initialize: function(){

			},
			build: function(){
				this.set('scale', 2000 / window.App.Models.Logo.get('meshWidth'))
				this.buildLogo();
				this.resize();
				this.exportLogo();
				this.setMesh();
			},
			buildLogo: function(){
				var two = new Two({type: Two.Types['canvas'], autostart: true});
				var shape = two.interpret($(Logo)[0]);
				var dimensions = shape.getBoundingClientRect();
				var meshWidth = Math.ceil(dimensions.width);
				var meshHeight = Math.ceil(dimensions.height);
				shape.fill = '#000000';
				this.set({
					'meshWidth' : meshWidth,
					'meshHeight' : meshHeight
				});
			},
			exportLogo: function(){
				var canvasWidth = this.get('canvasWidth');
				var canvasHeight = this.get('canvasHeight');
				var meshWidth = this.get('meshWidth');
				var meshHeight = this.get('meshHeight');
				var two = new Two({type: Two.Types['canvas'], autostart: true});
				var shape = two.interpret($(Logo)[0]);
				var dimensions = shape.getBoundingClientRect();
				var logoWidth = Math.ceil(dimensions.width);
				var logoHeight = Math.ceil(dimensions.height);
				var dpRatio = window.devicePixelRatio || 1;
				var scale = (meshWidth / logoWidth) * dpRatio;
				if (window.WebGLRenderingContext) shape.scale = scale;
				if (window.WebGLRenderingContext){
					two.width = logoWidth*scale;
					two.height = logoHeight*scale;
				}
				_.defer(_.bind(function(){
					var canvas = $(two.renderer.domElement);
					var context = canvas[0].getContext('2d');
					var imgd = context.getImageData(0, 0, canvas.width(), canvas.height());
					logoImage = canvas[0].toDataURL('image/png', 1);
					this.set('logoImage' , logoImage, { silent: true});
					this.trigger('change:logoImage')
				}, this));
			},
			resize: function(){
				var width = 2000;
				var meshWidth = this.get('meshWidth');
				var meshHeight = this.get('meshHeight');
				var logo = $('#exporter');
				var meshAR = this.get('meshHeight')/this.get('meshWidth');
				var canvasWidth = width;
				var canvasHeight = width * meshAR;
				$('#exporter').css({
					width : canvasWidth,
					height : canvasHeight * 3
				})
				this.set({
					'meshWidth' : canvasWidth,
					'meshHeight' : canvasWidth * meshAR,
					'canvasWidth' : canvasWidth,
					'canvasHeight' : canvasHeight * 3
				})
				// if($('#canvas').width() > 1000) this.set('SAdefinition', 128);
			},
			setMesh: function(){
				var xSegs = this.get('SAdefinition')/2; // must be odd (not pair)
				var ySegs = 1;
				this.set({
					xSegs : xSegs,
					ySegs : ySegs,
					restDistanceX : this.get('meshWidth') / xSegs,
					restDistanceY : this.get('meshHeight') / ySegs
				});
			}
		});
		return Logomodel;
	}
);