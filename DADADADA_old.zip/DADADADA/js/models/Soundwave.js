// ┌────────────────────────────────────────────────────────────────────┐
// | SoundwaveModel.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone'
	],
	function(Backbone){
		
		var Soundwavemodel = Backbone.Model.extend({
			defaults: {
				friction: 1,
				timeStep: 0.1,
				restLength: 0,
				amount: 0,
				mass: 15,
				invMass: 0,
				strength : 0.1,
				points: [],
				wave: [],
				padding: 2,
				mamb: null,
				mode : null,
				mouseX : 0,
				mouseY : 0
			},
			initialize: function(data){
				_.extend(this,data);
				this.set('amount', window.App.Models.Logo.get('SAdefinition')/2);
				this.set('invMass', 1 / this.get('mass'));
				this.set('mamb', this.get('invMass') * this.get('invMass'));
				window.App.Models.Analyser.on('change:source', this.setDefaults, this);
				window.App.Models.Logo.on('change:type', this.setDefaults, this);
				this.setDefaults();
				var width = $('#canvas').width();
				var totalPoints = this.get('amount') + 2 * this.get('padding');
				var points = _.clone(this.get('points'));
				for (var i = 0; i <= totalPoints; i++) {
					points[i] = {
						y: 0,
						x: width/(totalPoints - 2 * this.get('padding')) * (i-this.get('padding')),
						o: 0,
						fixed: i < 1 || i > this.get('amount') + 2 * this.get('padding') - 1,
						index: i
					}
				}
				this.set('wave', _.rest(_.initial(points,this.get('padding')),this.get('padding')));
				this.set('points', points);
			},
			updateWave: function(){
				var force = 1 - this.get('friction') * this.get('timeStep') * this.get('timeStep');
				var points = _.clone(this.get('points'));
				if(window.App.Models.Analyser.get('source')!== 'none'){
					var oscillator;
					var average = window.App.Models.Analyser.get('average');
					if(this.position == 'top') oscillator = this.get('amount')/2 + this.get('padding') + Math.round( this.get('amount')/2 * window.App.Models.Analyser.get('deep'));
					if(this.position == 'bot') oscillator = this.get('amount')/2 + this.get('padding') - Math.round( this.get('amount')/2 * window.App.Models.Analyser.get('pitch'));
					points[oscillator].y = average * $('#logo').height()/4;
				}
				for (var i = 0, l = points.length-1; i <= l; i++) {
					var point = points[i];
					var dy = (point.y - point.o) * force;
					point.o = point.y;
					point.y = point.y + dy;
					if( i > 0 ){
						var delta = { x : points[i].x - points[i-1].x, y: points[i].y - points[i-1].y }
						var dist = this.lineDistance(points[i-1],points[i]);
						var normDistStrength = (dist - this.get('restLength')) / (dist * this.get('mamb')) * this.get('strength');
						delta.y *= normDistStrength * this.get('invMass') * 0.2;
						if (!points[i-1].fixed) points[i-1].y += Math.min(delta.y , $('#canvas').height()/3 - points[i-1].y - Math.random()*10);
						if (!points[i].fixed) points[i].y -=  Math.min(delta.y , $('#canvas').height()/3 - points[i].y - Math.random()*10);
					}
				}
				this.set('points', points);
				this.set('wave', _.rest(_.initial(points,this.get('padding')),this.get('padding')));
			},
			lineDistance: function( point1, point2 ){
				var xs = Math.pow(point2.x - point1.x, 2);
				var ys = Math.pow(point2.y - point1.y, 2);
				return Math.sqrt( xs + ys );
			},
			setDefaults: function(){
				var source = window.App.Models.Analyser.get('source');
				var type = window.App.Models.Logo.get('type');
				if(type == 'raster'){
					if(source == 'mic' || source == 'audio' || source == 'video'){
						this.set({
							friction: 3,
							timeStep: 0.1,
							mass: 15
						});
					}
					if(source == 'none'){
						this.set({
							friction: 1,
							timeStep: 0.1,
							mass: 15
						});
					}
				}
				if(type == 'vector'){
					if(source == 'mic' || source == 'audio' || source == 'video'){
						this.set({
							friction: 3,
							timeStep: 0.1,
							mass: 15
						});
					}
					if(source == 'none'){
						this.set({
							friction: 2,
							timeStep: 0.15,
							mass: 15
						});
					}
				}
				this.set('amount', window.App.Models.Logo.get('SAdefinition')/2);
				this.set('invMass', 1 / this.get('mass'));
				this.set('mamb', this.get('invMass') * this.get('invMass'));
			},
			mouseMove: function(e){
				this.set('mouseX', e.pageX);
				this.set('mouseY', e.pageY);
				this.mouseStrength();
			},
			mouseStrength: function(){
				var topWaveModel = window.App.Models.TopWave;
				var botWaveModel = window.App.Models.BotWave;
				var analyserModel = window.App.Models.Analyser;
				var topPoints = topWaveModel.get('points');
				var botPoints = botWaveModel.get('points');
				var canvas = $('#canvas');
				var canvasTop = canvas.offset().top;
				var canvasLeft = canvas.offset().left;
				var canvasHeight = canvas.height();
				var mouseX = this.get('mouseX');
				var mouseY = this.get('mouseY');
				var p1 = { x: mouseX, y: mouseY };
				var topClosest = _.sortBy(topPoints, _.bind(function(point){
					var p2 = { x: canvas.offset().left + point.x, y: canvasTop + point.y + canvasHeight / 3 };
					return this.lineDistance(p1,p2);
				},this));
				var botClosest = _.sortBy(botPoints, _.bind(function(point){
					var p2 = { x: canvas.offset().left + point.x, y: canvasTop + point.y + canvasHeight / 3 };
					return this.lineDistance(p1,p2);
				},this));
				var topPoint = _.first(topClosest);
				var botPoint = _.first(botClosest);
				var topDistance = this.lineDistance({ x:mouseX, y:mouseY },{ x: canvasLeft + topPoint.x, y: canvasTop + canvasHeight / 3 + botPoint.y })
				var botDistance = this.lineDistance({ x:mouseX, y:mouseY },{ x: canvasLeft + botPoint.x, y: canvasTop + canvasHeight - canvasHeight / 3 + botPoint.y })
				var topLimit = canvasTop + canvasHeight / 3;
				var botLimit = canvasTop + canvasHeight - canvasHeight / 3;
				var strengthReduction = 50;
				var topStrength = (mouseY - topLimit - canvasHeight / 3) / strengthReduction;
				var botStrength = ((botLimit - canvasHeight / 3) - mouseY) / strengthReduction;
				if (!topPoint.fixed && topDistance < canvasHeight / 3 && mouseY > topLimit) {
					if(analyserModel.get('source') == 'none') topPoint.y -= topStrength;
				}
				
				if (!botPoint.fixed && botDistance < canvasHeight / 3 && mouseY < botLimit) {
					if(analyserModel.get('source') == 'none') botPoint.y -= botStrength;
				}
			},
			lineDistance: function( point1, point2 ){
				var xs = Math.pow(point2.x - point1.x, 2);
				var ys = Math.pow(point2.y - point1.y, 2);
				return Math.sqrt( xs + ys );
			},
			step: function(){
				this.updateWave();
			}
		});
		return Soundwavemodel;
	}
);