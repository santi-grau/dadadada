// ┌────────────────────────────────────────────────────────────────────┐
// | MeshParticle.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone'
	],
	function(Backbone){
		var Particle = Backbone.Model.extend({
			initialize: function(data){
				_.extend(this,data);
				var imageWidth = window.App.Models.Logo.get('meshWidth');
				var imageHeight = window.App.Models.Logo.get('meshHeight');
				var clothFunction = this.plane(imageWidth, imageHeight);
				var x = this.x;
				var y = this.y;
				var z = this.z;
				var mass = 10;
				var row = this.row;
				var col = this.col;
				this.position = clothFunction(x, y); // position
				this.previous = clothFunction(x, y); // previous
				this.original = clothFunction(x, y);
				this.a = new THREE.Vector3(0, 0, 0); // acceleration
				this.mass = mass;
				this.row = row;
				this.col = col;
				this.invMass = 1 / mass;
				this.tmp = new THREE.Vector3();
				this.tmp2 = new THREE.Vector3();
			},
			addForce: function(force){
				this.a.add(
					this.tmp2.copy(force).multiplyScalar(this.invMass)
				);
			},
			integrate: function(timesq){
				var newPos = this.tmp.subVectors(this.position, this.previous);
				newPos.multiplyScalar(.5).add(this.position);
				newPos.add(this.a.multiplyScalar(timesq));
				this.tmp = this.previous;
				this.previous = this.position;
				this.position = newPos;
				this.a.set(0, 0, 0);
			},
			plane: function(width,height){
				return function(u, v) {
					var x = (u-0.5) * width;
					var y = (v-0.5) * height;
					var z = 0;
					return new THREE.Vector3(x, y, z);
				};
			}
		});
		return Particle;
	}
);