// ┌────────────────────────────────────────────────────────────────────┐
// | LogoModel.js
// └────────────────────────────────────────────────────────────────────┘
define(
	[
		'backbone',
		'two',
		'text!svg/logo_compound.svg'
	],
	function(Backbone, Two, Logo){
		var Logomodel = Backbone.Model.extend({
			defaults: {
				SAdefinition: 128,
				canvasWidth: null, // total canvas width
				canvasHeight: null, // total canvas height
				meshWidth: null, // mesh width
				meshHeight: null, // mesh height
				logo: null,
				color: '#107695',
				color2: '#107695',
				color3: '#107695',
				background: '#fff9c5',
				logoImage : null,
				mass: 1,
				xSegs: null,
				ySegs: null,
				TIMESTEP: 18 / 1000,
				TIMESTEP_SQ: (18 / 1000) * (18 / 1000),
				wind: false,
				particles: [],
				constrains: [],
				restDistanceX : null,
				restDistanceY : null,
				type: 'raster',
				resizing: false
			},
			initialize: function(){
				this.buildLogo();
				this.resize();
				this.exportLogo();
				this.setMesh();
			},
			buildLogo: function(){
				var two = new Two({type: Two.Types['canvas'], autostart: true});
				var shape = two.interpret($(Logo)[0]);
				var dimensions = shape.getBoundingClientRect();
				var meshWidth = Math.ceil(dimensions.width);
				var meshHeight = Math.ceil(dimensions.height);
				shape.fill = '#000000';
				this.set({
					'meshWidth' : meshWidth,
					'meshHeight' : meshHeight
				});
			},
			exportLogo: function(){
				var canvasWidth = this.get('canvasWidth');
				var canvasHeight = this.get('canvasHeight');
				var meshWidth = this.get('meshWidth');
				var meshHeight = this.get('meshHeight');
				var two = new Two({type: Two.Types['canvas'], autostart: true});
				var shape = two.interpret($(Logo)[0]);
				var dimensions = shape.getBoundingClientRect();
				var logoWidth = Math.ceil(dimensions.width);
				var logoHeight = Math.ceil(dimensions.height);
				var dpRatio = window.devicePixelRatio || 1;
				var scale = (meshWidth / logoWidth) * dpRatio;
				if (window.WebGLRenderingContext) shape.scale = scale;
				if (window.WebGLRenderingContext){
					two.width = logoWidth*scale;
					two.height = logoHeight*scale;
				}
				setTimeout(_.bind(function(){
					var canvas = $(two.renderer.domElement);
					var context = canvas[0].getContext('2d');
					var imgd = context.getImageData(0, 0, canvas.width(), canvas.height());
					logoImage = canvas[0].toDataURL('image/png', 1);
					this.set('logoImage' , logoImage);
				}, this), 1000);
			},
			resize: function(){
				var meshWidth = this.get('meshWidth');
				var meshHeight = this.get('meshHeight');
				var logo = $('#logo');
				var maxw = meshWidth;
				var maxh = meshHeight*3;
				var canvasAR = maxh/maxw;
				var meshAR = this.get('meshHeight')/this.get('meshWidth');
				var boxAR = logo.height()/logo.width();
				var canvasWidth = logo.width();
				var canvasHeight = logo.width() * canvasAR;
				if(canvasAR > boxAR){
					canvasWidth = logo.height() / canvasAR;
					canvasHeight = logo.height();
				}
				$('#canvas').css({
					width : canvasWidth,
					height : canvasHeight,
					left : (logo.width() - canvasWidth)/2,
					top : (logo.height() - canvasHeight)/2
				})
				this.set({
					'meshWidth' : canvasWidth,
					'meshHeight' : canvasWidth * meshAR,
					'canvasWidth' : canvasWidth,
					'canvasHeight' : canvasHeight
				})
				// if($('#canvas').width() > 1000) this.set('SAdefinition', 128);
			},
			setMesh: function(){
				var xSegs = this.get('SAdefinition')/2; // must be odd (not pair)
				var ySegs = 1;
				this.set({
					xSegs : xSegs,
					ySegs : ySegs,
					restDistanceX : this.get('meshWidth') / xSegs,
					restDistanceY : this.get('meshHeight') / ySegs
				});
			}
		});
		return Logomodel;
	}
);